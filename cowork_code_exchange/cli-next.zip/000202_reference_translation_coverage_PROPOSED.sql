-- =============================================================================
-- 000202_reference_translation_coverage.sql   ***PROPOSED — DO NOT APPLY***
-- Prodotto da Cowork (read-only sulla SoT). Numerazione indicativa: assegnala
-- il CLII al momento dell'ingest. Nessuna migration applicata.
-- -----------------------------------------------------------------------------
-- Gate di COMPLETEZZA per l'i18n dei dati di riferimento (ADR-0029).
-- Complementa la vista di INTEGRITA' `sys.v_reference_translation_orphans`
-- (mig 000190): quella prova che nessuna traduzione punta a righe morte; QUESTA
-- prova che ogni riga viva con testo IT-canonico ha il suo overlay nella lingua
-- bersaglio (default 'en'). Entrambe sono PILOTATE DAL REGISTRO
-- `sys.sys_translatable_field`: qualunque tabella nuova (incluse le
-- `sys_occupation_classifications` ISCO/CP proposte) diventa coperta
-- AUTOMATICAMENTE appena registra i suoi campi. Pura lettura => idempotente,
-- re-runnable, stabile.
-- =============================================================================

CREATE OR REPLACE FUNCTION sys.fn_reference_translation_coverage(target_locale varchar DEFAULT 'en')
RETURNS TABLE (
  entity_table varchar,
  field        varchar,
  base_rows    bigint,   -- righe con testo IT-canonico non vuoto (in-row)
  translated   bigint,   -- overlay presenti nella lingua bersaglio
  missing      bigint    -- base_rows - translated: >0 = buchi EN ; <0 = anomalia (overlay su base vuoto)
) AS $$
DECLARE
  r record;
  b bigint;
  t bigint;
BEGIN
  FOR r IN
    SELECT f.entity_table, f.entity_pk_column, f.field, f.entity_field_column
    FROM sys.sys_translatable_field f
    ORDER BY f.entity_table, f.field
  LOOP
    -- difensivo: solo tabelle realmente esistenti nello schema sys
    IF to_regclass('sys.' || r.entity_table) IS NULL THEN
      CONTINUE;
    END IF;

    -- conteggio righe base con testo IT-canonico non vuoto (dinamico sul registro)
    EXECUTE format(
      'SELECT count(*) FROM sys.%I WHERE %I IS NOT NULL AND length(trim(%I::text)) > 0',
      r.entity_table, r.entity_field_column, r.entity_field_column
    ) INTO b;

    -- overlay presenti per (entity_table, field, locale)
    SELECT count(*) INTO t
    FROM sys.sys_reference_translations x
    WHERE x.entity_table = r.entity_table
      AND x.field        = r.field
      AND x.locale       = target_locale;

    entity_table := r.entity_table;
    field        := r.field;
    base_rows    := b;
    translated   := t;
    missing      := b - t;   -- signed: >0 sotto-copertura, <0 anomalia
    RETURN NEXT;
  END LOOP;
END $$ LANGUAGE plpgsql STABLE;

-- Vista comoda (lingua bersaglio 'en', la "seconda" lingua rispetto all'IT canonico)
CREATE OR REPLACE VIEW sys.v_reference_translation_coverage AS
  SELECT * FROM sys.fn_reference_translation_coverage('en');

-- -----------------------------------------------------------------------------
-- GATE (da inserire in CI + docs/kb/tools/status_dashboard.py):
--   Completezza  -> deve restituire 0 righe:
--     SELECT * FROM sys.v_reference_translation_coverage WHERE missing > 0;
--   Anomalia (overlay EN su base IT vuoto) -> investigare se != 0:
--     SELECT * FROM sys.v_reference_translation_coverage WHERE missing < 0;
--
-- Post-condition fail-loud (opzionale, se si vuole bloccare la migration stessa):
-- DO $$
-- DECLARE n int;
-- BEGIN
--   SELECT count(*) INTO n FROM sys.v_reference_translation_coverage WHERE missing > 0;
--   RAISE NOTICE 'i18n coverage: % campi con overlay EN mancanti', n;
-- END $$;
-- -----------------------------------------------------------------------------
