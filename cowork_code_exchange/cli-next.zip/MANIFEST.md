# cli-next — pacchetto per Claude Code CLI (asse professione ISCO-08 + CP2021, bilingue)

Generato da Cowork il 2026-07-22. Riferimento: proposte in docs/kb/COWORK_INBOX.md (entries 2026-07-22).
Contiene SOLO le versioni definitive e complete; intermedi/subset (seed EN, overlay ISCO-only, overlay CP-only, bilingue interim) esclusi.

## File
1. heuresys_classificazioni_reconciliation_2026-07-22.md
   Riconciliazione/audit/gap + design (DDL PROPOSED): sys_occupation_classifications, sys_occupation_classification_mappings, aggancio ESCO. Contesto e razionale.
2. occupation_classifications_seed_IT_2026-07-22.csv   [BASE - IT canonico in-row]
   Colonne: scheme,code,parent_code,level,name  |  2121 righe: ISCO_08 619 (name IT da ESCO) + CP_2021 1502 (name IT da Istat).
   -> INSERT in sys.sys_occupation_classifications (name = IT canonico in-row).
3. occupation_reference_translations_EN_FULL_2026-07-22.csv   [OVERLAY EN]
   Colonne: entity_table,entity_ref,field,locale,text,source  |  2121 righe: 619 ISCO (source=HARVEST) + 1502 CP2021 (source=LLM). entity_ref = <scheme>:<code>.
   -> INSERT in sys.sys_reference_translations risolvendo entity_id da (scheme,code) dopo il load del BASE.
4. 000202_reference_translation_coverage_PROPOSED.sql   [GATE i18n]
   fn_reference_translation_coverage() + v_reference_translation_coverage (registry-driven). Numerazione indicativa.
5. occupation_classifications_bilingual_2026-07-22.csv   [SOLO ISPEZIONE]
   name_it + name_en affiancati. Non per il load.

## Ordine di esecuzione (proposto; go = Enzo)
1. Applicare 000200 (sys_occupation_classifications) + 000201 (mappings) + 000202 (coverage view).
2. Caricare il BASE (file 2) in sys_occupation_classifications.
3. Caricare gli OVERLAY EN (file 3) in sys_reference_translations (risolvi entity_id da scheme:code).
4. Registrare (sys_occupation_classifications,'name') in sys_translatable_field.
5. Gate:  SELECT * FROM sys.v_reference_translation_coverage WHERE missing>0  ->  deve essere VUOTO.
6. DoD live-E2E: GET /v1/occupation-classifications?scheme=ISCO_08 su albero reale.

## Conteggi attesi (verifica)
ISCO_08: 619 (livelli 10/43/130/436). CP_2021: 1502 (9/40/130/510/813). Overlay EN: 2121 (619 HARVEST + 1502 LLM). 0 orfani.
