---
title: "Classificazioni ISCO / ESCO / ATECO / NACE — Riconciliazione, Audit e Design di chiusura gap in heuresys-advanced"
version: 1.0
date: 2026-07-22
author: Cowork (Claude Opus) — supervisore/architetto (read-only sulla SoT)
status: Draft — proposta (nessuna scrittura sul progetto oltre COWORK_INBOX)
project: heuresys-advanced
tags:
  - classificazioni
  - ateco
  - nace
  - isco
  - esco
  - cp2021
  - hrms
  - reconciliation
  - gap-analysis
---

# Classificazioni ISCO / ESCO / ATECO / NACE — Riconciliazione, Audit e Design di chiusura gap in heuresys-advanced

> [!abstract] Executive summary
> heuresys-advanced **ha già** un substrato di classificazione maturo e popolato: l'asse **attività economica** (ATECO 2025 + NACE) è completo e corretto, con crosswalk bidirezionale; l'asse **professione** esiste via ESCO, con i codici ISCO presenti come attributo. La verifica **live** sul DB (`localhost:5433/heuresys_advanced`, 2026-07-22) smentisce l'ipotesi iniziale di dati incompleti: **ATECO_2025 = 3257 righe = totale ufficiale Istat**. I gap reali sono due e netti: **(A) manca un catalogo ISCO-08 gerarchico standalone** (oggi l'ISCO vive solo come stringa su `sys_esco_occupation_mappings`); **(B) manca CP2021** (professioni Istat, mai impostato). Un terzo item minore è una **verifica di qualità dati sul NACE legacy**. Questo documento riconcilia teoria e schema reale, presenta l'audit vs fonti ufficiali, e propone un design di chiusura gap allineato alle convenzioni `sys.*` e agli invarianti esistenti — **DDL PROPOSED, non applicata**. L'unica scrittura sul progetto è l'entry corrispondente in `docs/kb/COWORK_INBOX.md`.

---

## 1. Scopo, ambito e vincolo di governance

Lo scopo è collegare l'inquadramento teorico delle classificazioni internazionali/nazionali (ISCO-08, ESCO, ATECO 2025, NACE Rev. 2.1, CP2021) allo **stato realmente implementato** in heuresys-advanced, produrre un **audit** dei dati caricati rispetto alle fonti ufficiali, isolare i **gap** che hanno valore per un HRMS, e proporre un **design di chiusura** eseguibile dal Claude Code CLI.

Il documento rispetta la governance del progetto: la Source of Truth di stato è `docs/kb/` (CLI-owned); **Cowork è read-only** su di essa. L'unica scrittura ammessa è l'append della proposta corrispondente in `docs/kb/COWORK_INBOX.md`. Tutto il DDL qui riportato è **PROPOSED / DO-NOT-APPLY**: nessuna migration è stata creata o applicata, nessun dato scritto, nessun commit effettuato. Le decisioni di *cosa* implementare restano a Enzo; il *come* è la proposta tecnica.

L'audience è tecnica (data engineer / architetto DB) ma il documento è autoesplicativo anche per un lettore di prodotto.

## 2. Le quattro (più una) classificazioni e le catene di derivazione

Due assi **ortogonali** governano un HRMS: *cosa fa l'azienda* (attività economica) e *cosa fa la persona* (professione). Non sono intercambiabili e si incontrano solo quando si collega un dipendente alla sua azienda.

| Dimensione | Classifica | Ente | Livelli | Formato codice | Uso in HRMS |
|---|---|---|---|---|---|
| Attività economica | **NACE Rev. 2.1** | Eurostat (UE) | 4 | lettera + fino a 4 cifre (`20.51`) | settore dell'azienda (ponte UE) |
| Attività economica | **ATECO 2025** | Istat (IT) | 6 | lettera + fino a 6 cifre (`62.10.00`) | settore dell'azienda (dettaglio nazionale) |
| Professione | **ISCO-08** | ILO (globale) | 4 | 4 cifre (`2511`) | occupazione standard internazionale |
| Professione | **ESCO** | Commissione UE | occupazioni + skill | URI + codice ISCO | matching occupazione↔skill (EU-native) |
| Professione | **CP2021** | Istat (IT) | 5 | 5 cifre | occupazione, dettaglio nazionale italiano |

Le catene di derivazione sono la chiave per capire i "ponti" comuni: tagliando le cifre finali di un codice nazionale si risale al livello europeo/internazionale.

```mermaid
flowchart LR
  ISIC["ISIC Rev.4<br/>ONU — mondiale"] --> NACE["NACE Rev.2.1<br/>Eurostat — UE (L1-4)"]
  NACE --> ATECO["ATECO 2025<br/>Istat — IT (L1-6)"]
  ISCO["ISCO-08<br/>ILO — globale (L1-4)"] --> ESCO["ESCO<br/>UE — occupazioni+skill"]
  ISCO --> CP["CP2021<br/>Istat — IT (L1-5)"]
```

I due assi come si incontrano nell'HRMS:

```mermaid
flowchart TB
  Tenant["Tenant / Azienda"] --> Ax1["Asse ATTIVITÀ<br/>ATECO 2025 / NACE"]
  Role["Dipendente / job_role"] --> Ax2["Asse PROFESSIONE<br/>ISCO-08 / ESCO / CP2021"]
  Ax1 -. "crosswalk ATECO↔NACE" .- Ax1
  Ax2 -. "crosswalk ISCO↔ESCO↔CP" .- Ax2
```

## 3. Stato reale in heuresys-advanced (live-verified 2026-07-22)

Le tabelle esistono nello schema `sys.*` e seguono un pattern uniforme (PK uuid `gen_random_uuid()`, colonne prefissate dall'entità, `scheme`/`code`/`parent_code`, unique `(scheme, code)`, indice sul `parent_code`, `metadata jsonb`, trigger `set_updated_at`).

**Asse attività economica** — `sys.sys_activity_classifications` (mig `000007`) è un catalogo *unificato* che ospita più schemi nella stessa tabella, distinti da `activity_classification_scheme` (CHECK: `ATECO_2025`, `NACE_REV_2_1`, `ATECO_2007`, `NACE_REV_2`, rilassato in `000032` per includere le basi `ATECO`/`NACE`). Il crosswalk è `sys.sys_activity_classification_mappings` (self-referencing source/target).

**Asse professione** — `sys.sys_esco_occupation_mappings` (mig `000010`) collega `job_role` ↔ occupazione ESCO (`esco_uri`, `esco_label`) e porta il codice ISCO come **attributo** `esco_occupation_mapping_isco_code varchar(16)` (indicizzato). Completano il quadro `sys_esco_occupation_embeddings` (pgvector, mig `000060`, con `isco_code text`) e `sys_occupation_skill_requirements` (mig `000123`).

Conteggi **live** (verified-by in §9):

| Scheme / oggetto | Livelli · distribuzione | Righe | Lettura |
|---|---|---|---|
| `ATECO_2025` | L1-6 · 22/87/287/651/920/1290 | **3257** | ✅ catalogo completo, tutti i 6 livelli |
| `ATECO` (legacy) | L5-6 · 920/1290 | 2210 | brownfield pre-2025, solo livelli nazionali |
| `NACE` (legacy) | L1-4 · 22/88/305/651 | 1066 | brownfield, base europea |
| `sys_activity_classifications` **totale** | — | **6533** | 3257 + 2210 + 1066 |
| crosswalk `sys_activity_classification_mappings` | NARROWER 2865 + BROADER 2865 | **5730** | ✅ bidirezionale, confidence 1.000 |
| `sys_esco_occupation_mappings` | 3070 con ISCO · 3000 ISCO distinti | **7675** | ISCO presente solo come attributo |
| catalogo **ISCO-08** gerarchico | — | **0** | ❌ assente |
| **CP2021** | — | **0** | ❌ assente (nessuna tabella, nessun watermark) |

```mermaid
erDiagram
  sys_activity_classifications ||--o{ sys_activity_classification_mappings : "source/target (ATECO↔NACE)"
  sys_activity_classifications ||--o{ sys_enterprise_typing_profiles : "industry_class_id"
  sys_tenancies ||--o{ sys_enterprise_typing_profiles : tenant
  sys_job_families ||--o{ sys_job_roles : family
  sys_job_roles ||--o{ sys_esco_occupation_mappings : maps
  sys_esco_occupation_mappings }o--|| ISCO_flat : "isco_code varchar (attributo, NON normalizzato)"
```

Il caricamento di ATECO 2025 non è manuale: esiste un connettore reale, `apps/api/src/modules/reference-sync/istat-ateco-connector.ts`, che scarica l'XLSX ufficiale `StrutturaATECO-2025-IT-EN-DE.xlsx` (foglio "ATECO 2025 Struttura", 3257 righe, header validato, guardie fail-loud) e fa upsert nello scheme `ATECO_2025`. Il watermark è tracciato in `brownfield.source_watermarks` (`ATECO_2025 = UNCHANGED`). L'asse industriale canonico è `ATECO_2025` per decisione di Enzo (mig `000119`, AskUserQuestion 2026-06-15).

## 4. Audit — DB vs fonti ufficiali

| Oggetto | DB (live) | Ufficiale | Esito |
|---|---|---|---|
| ATECO 2025 (totale) | 3257 | 3257 (Istat) | ✅ **match esatto** |
| ATECO 2025 per livello | 22/87/287/651/920/1290 | idem (Istat) | ✅ struttura coerente |
| crosswalk ATECO↔NACE | 5730 (2865+2865) | derivazione deterministica | ✅ coperto (L5→L4 920/920; ATECO_2025 1945/1945) |
| ESCO occupation mappings | 7675 (3000 ISCO distinti) | — | ✅ presente (ISCO come attributo) |
| NACE base (legacy) | 1066 · L2/L3 = 88/305 | NACE Rev. 2.1 (≈88 divisioni) | ⚠️ **da confermare** (vedi nota) |
| ISCO-08 catalogo | 0 | 10/43/130/436 = 619 (ILO) | ❌ **gap** |
| CP2021 | 0 | 5 livelli · 813 unità professionali (Istat) | ❌ **gap** |

> [!note] Nota onestà (correzione di ipotesi)
> In fase esplorativa avevo ipotizzato ATECO_2025 *incompleto* (1945 righe). **Falso**: le 1945 erano solo i codici *crosswalk-eligible* (con `parent_code` = codice NACE); il catalogo completo è 3257. La verifica live ha corretto l'ipotesi.

> [!warning] Item qualità dati — NACE legacy
> ATECO_2025 espone L1-4 con 22/87/287/… mentre lo scheme `NACE` legacy mostra 22/88/305/651. La divergenza a livello divisione (87 vs 88) è **verosimilmente variazione nazionale legittima** (ATECO 2025 ha 87 divisioni contro le 88 di NACE), **non** un errore. Il conteggio gruppi del NACE legacy (305) va confrontato con il valore ufficiale NACE Rev. 2.1 su Eurostat/RAMON (non estraibile via fetch in questa sessione). Poiché l'asse canonico è `ATECO_2025`, i due schemi base legacy (`ATECO`/`NACE`) sono candidati o a riconciliazione o a deprecazione controllata — decisione di prodotto, non urgenza tecnica.

## 5. Gap analysis

**Gap A — Catalogo ISCO-08 gerarchico standalone (assente).** Oggi l'ISCO esiste solo come `esco_occupation_mapping_isco_code varchar(16)`: 3000 valori distinti, non normalizzati, senza gerarchia major→sub-major→minor→unit, senza etichette ufficiali, senza integrità referenziale. Un HRMS che vuole (a) reportistica per gruppo professionale ISCO, (b) benchmark internazionali, (c) explainability AI-Act ancorata a uno standard, ha bisogno del **tree ISCO-08** come catalogo di prima classe. È lo stesso pattern già adottato per l'asse attività (dove ATECO/NACE *sono* catalogo, non attributo).

**Gap B — CP2021 (assente).** Per un HRMS *italiano* la professione del dipendente va espressa anche in **CP2021** (5 livelli, 813 unità professionali), la classificazione Istat derivata da ISCO-08 e usata da INPS/Uniemens (obbligatoria dal maggio 2025, abbinata proprio ad ATECO 2025). Senza CP2021 manca il ponte verso gli adempimenti nazionali (contratti, flussi previdenziali, statistiche del lavoro).

**Gap C — Qualità dati NACE legacy (minore).** Vedi §4: confermare la currency del NACE base o deprecare i due schemi base a favore di `ATECO_2025`.

Perché contano insieme: l'HRMS collega la **professione** del dipendente (ISCO/ESCO/CP2021) al **settore** dell'azienda (ATECO/NACE). L'asse attività è completo; l'asse professione è coperto solo lato ESCO. Chiudere i gap A/B rende l'asse professione simmetrico all'asse attività, con gli stessi ponti standardizzati.

## 6. Design di chiusura gap (DDL PROPOSED — non applicata)

Il design **rispecchia il pattern esistente** dell'asse attività, così l'asse professione risulta simmetrico e riusa convenzioni, API-shape e logiche di crosswalk già collaudate. Invarianti onorati: naming `sys.sys_<entity>` + colonne prefissate; PK uuid `gen_random_uuid()`; `scheme`/`code`/`parent_code`; unique `(scheme, code)`; indice parziale sul `parent_code`; `metadata jsonb`; trigger `sys.sys_set_updated_at()`; nessun PII (ADR-0023 no-PII globale); catalogo indipendente dall'assegnazione interna (ADR-0016 — ESCO/ISCO restano standard, non si accoppiano a `job_role`).

### 6.1 Catalogo professioni standalone

```sql
-- 000200_occupation_classifications.sql  (PROPOSED — DO NOT APPLY)
-- Asse professione standalone: ISCO-08 (L1-4) + CP2021 (L1-5) + ESCO opz.
CREATE TABLE IF NOT EXISTS sys.sys_occupation_classifications (
  occupation_classification_id          uuid         PRIMARY KEY DEFAULT gen_random_uuid(),
  occupation_classification_scheme      varchar(32)  NOT NULL,
  occupation_classification_code        varchar(32)  NOT NULL,
  occupation_classification_parent_code varchar(32),
  occupation_classification_name        varchar(255) NOT NULL,
  occupation_classification_description  text,
  occupation_classification_level       smallint,
  occupation_classification_metadata    jsonb        NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

DO $scheme_check$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'sys_occupation_classifications_scheme_check'
      AND conrelid = 'sys.sys_occupation_classifications'::regclass
  ) THEN
    ALTER TABLE sys.sys_occupation_classifications
      ADD CONSTRAINT sys_occupation_classifications_scheme_check
      CHECK (occupation_classification_scheme IN ('ISCO_08', 'CP_2021', 'ESCO'));
  END IF;
END $scheme_check$;

CREATE UNIQUE INDEX IF NOT EXISTS sys_occupation_classifications_scheme_code_uq
  ON sys.sys_occupation_classifications (occupation_classification_scheme, occupation_classification_code);

CREATE INDEX IF NOT EXISTS sys_occupation_classifications_parent_idx
  ON sys.sys_occupation_classifications (occupation_classification_scheme, occupation_classification_parent_code)
  WHERE occupation_classification_parent_code IS NOT NULL;

-- + trigger sys_occupation_classifications_set_updated_at (pattern 000007)
```

### 6.2 Crosswalk professioni

```sql
-- 000201_occupation_classification_mappings.sql  (PROPOSED — DO NOT APPLY)
-- Crosswalk ISCO↔CP2021, ISCO↔ESCO, ecc. (stesso pattern di 000007 §2).
CREATE TABLE IF NOT EXISTS sys.sys_occupation_classification_mappings (
  occupation_class_mapping_id         uuid         PRIMARY KEY DEFAULT gen_random_uuid(),
  occupation_class_mapping_source_id  uuid         NOT NULL REFERENCES sys.sys_occupation_classifications(occupation_classification_id) ON DELETE CASCADE,
  occupation_class_mapping_target_id  uuid         NOT NULL REFERENCES sys.sys_occupation_classifications(occupation_classification_id) ON DELETE CASCADE,
  occupation_class_mapping_kind       varchar(32)  NOT NULL DEFAULT 'EXACT'
    CHECK (occupation_class_mapping_kind IN ('EXACT','NARROWER','BROADER','RELATED','APPROXIMATE')),
  occupation_class_mapping_confidence numeric(4,3) NOT NULL DEFAULT 1.000,
  occupation_class_mapping_metadata   jsonb        NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS sys_occupation_class_mapping_pair_uq
  ON sys.sys_occupation_classification_mappings (occupation_class_mapping_source_id, occupation_class_mapping_target_id);
```

### 6.3 Aggancio all'ESCO esistente (additivo, non breaking)

L'attributo `esco_occupation_mapping_isco_code` resta; si aggiunge una **risoluzione** verso il nuovo catalogo ISCO senza toccare lo schema shipped (coerente con ADR-0016). Due opzioni, non mutuamente esclusive:

```sql
-- Opzione 1 (VIEW risolutiva, zero rischio schema):
CREATE OR REPLACE VIEW sys.sys_esco_isco_resolved AS
SELECT e.esco_occupation_mapping_id,
       e.esco_occupation_mapping_esco_uri,
       e.esco_occupation_mapping_isco_code,
       o.occupation_classification_id  AS isco_classification_id,
       o.occupation_classification_name AS isco_label
FROM sys.sys_esco_occupation_mappings e
LEFT JOIN sys.sys_occupation_classifications o
  ON o.occupation_classification_scheme = 'ISCO_08'
 AND o.occupation_classification_code   = split_part(e.esco_occupation_mapping_isco_code, '.', 1);

-- Opzione 2 (FK additiva nullable, se serve integrità dura — default-safe):
-- ALTER TABLE sys.sys_esco_occupation_mappings
--   ADD COLUMN esco_occupation_mapping_isco_class_id uuid
--   REFERENCES sys.sys_occupation_classifications(occupation_classification_id) ON DELETE SET NULL;
```

```mermaid
erDiagram
  sys_occupation_classifications ||--o{ sys_occupation_classification_mappings : "source/target (ISCO↔CP↔ESCO)"
  sys_occupation_classifications ||--o{ sys_esco_occupation_mappings : "risolve isco_code (VIEW/FK)"
  sys_activity_classifications ||--o{ sys_activity_classification_mappings : "ATECO↔NACE (esistente, simmetrico)"
```

### 6.4 Percorso di caricamento (connettori, come per ATECO)

Ricalca `istat-ateco-connector.ts`: seam iniettabile, header validato, guardie fail-loud, watermark. Sorgenti ufficiali:

- **ISCO_08** → struttura ILO (10 major / 43 sub-major / 130 minor / 436 unit = 619 nodi). Row-floor plausibilità ~600. Watermark `ISCO_08`.
- **CP_2021** → struttura Istat (5 livelli, 813 unità professionali). Row-floor ~800. Watermark `ISTAT_CP2021`.
- **Crosswalk ISCO↔ESCO** → derivazione **deterministica** dagli attributi già presenti (`esco_occupation_mapping_isco_code` → unit-group ISCO), stesso schema self-join di `000112`.
- **Crosswalk ISCO↔CP2021** → tavola di corrispondenza ufficiale Istat (CP2021 è cross-linkable con ISCO by design).

## 7. Piano di implementazione (work items per il CLI)

| WI | Contenuto | Dipendenze | Note |
|---|---|---|---|
| WI-1 | mig `000200`+`000201`: DDL catalogo + crosswalk professioni | — | default-safe (tabelle vuote = zero impatto), idempotente |
| WI-2 | Connettore ILO ISCO-08 + seed 619 nodi + test + watermark `ISCO_08` | WI-1 | fail-loud, fixtures in CI (no HTTP live) |
| WI-3 | Connettore Istat CP2021 + seed (L1-5, 813 UP) + test + watermark | WI-1 | sorgente Istat IT-only |
| WI-4 | Crosswalk ISCO↔ESCO (deterministico) + ISCO↔CP2021 (Istat) | WI-2, WI-3 | pattern `000112` |
| WI-5 | VIEW `sys_esco_isco_resolved` (+ FK additiva opzionale) | WI-2 | zero-breaking (ADR-0016) |
| WI-6 | Qualità dati NACE legacy: conferma currency o deprecazione controllata | — | decisione prodotto |

> [!important] Definition of Done — live E2E (regola Enzo)
> Nessun WI è "fatto" senza dimostrazione **live su dati reali**: es. `GET /v1/occupation-classifications?scheme=ISCO_08` che restituisce l'albero reale, e la risoluzione live `job_role → ESCO → ISCO → CP2021` su un tenant di test. Mock/green-test = solo scaffold intermedio. Input che solo Enzo può fornire (go migration, eventuale sorgente CP2021) → stato `blocked-on-Enzo`.

## 8. Cosa NON fare (anti-duplicazione)

- **NON** re-importare ATECO 2025 (già 3257, completo, con connettore live).
- **NON** ricreare il crosswalk ATECO↔NACE (già 5730, deterministico).
- **NON** creare uno schema `isco_*`/`cp_*` separato: riusare il pattern `sys.sys_occupation_classifications` (analogo ad `activity_classifications`) — coerente con gli invarianti I3/I4 (aux schema = staging/brownfield, non nuovi schemi di dominio).
- **NON** toccare `sys_esco_occupation_mappings` in modo breaking: l'aggancio è additivo (VIEW o FK nullable).

## 9. Appendix — verified-by

```text
# Conteggi live — psql localhost:5433/heuresys_advanced (user heuresys) — 2026-07-22
sys.sys_activity_classifications GROUP BY scheme,level:
  ATECO      5=920  6=1290                                   (tot 2210)
  ATECO_2025 1=22 2=87 3=287 4=651 5=920 6=1290              (tot 3257)
  NACE       1=22 2=88 3=305 4=651                           (tot 1066)
sys.sys_activity_classification_mappings GROUP BY kind:
  BROADER=2865  NARROWER=2865                                (tot 5730)
sys.sys_esco_occupation_mappings:
  total=7675  with_isco=3070  distinct_isco=3000
occupation/isco/cp tables (information_schema):
  staging.wave1_esco_occupation_mappings
  sys.sys_esco_occupation_embeddings
  sys.sys_esco_occupation_mappings
  sys.sys_occupation_skill_requirements
  → nessuna tabella ISCO-08 gerarchica, nessuna CP2021
brownfield.source_watermarks:
  ATECO_2025=UNCHANGED  ESCO=UNCHANGED  ESCO_SKILL_HIERARCHY=IDLE
  → nessun watermark ISTAT_CP2021 (era solo esempio in commento mig 000095)

# Evidenza schema/codice (read-only, D:\heuresys-advanced)
db/migrations/000007_enterprise_typing.sql   → sys_activity_classifications (+mappings)
db/migrations/000010_job_role_model.sql      → sys_esco_occupation_mappings (isco_code varchar(16))
db/migrations/000032_..._check_relax.sql     → CHECK scheme rilassato (ATECO/NACE base)
db/migrations/000112_populate_ateco_nace_crosswalk.sql → crosswalk deterministico
db/migrations/000119_enterprise_typing_test_tenants.sql → industry axis = ATECO_2025
apps/api/src/modules/reference-sync/istat-ateco-connector.ts → XLSX ufficiale, 3257 righe
max migration corrente: 000199 → proposte da 000200
```

## 10. Fonti

- Struttura ATECO 2025 (Istat): [documentazione ATECO](https://www.istat.it/classificazione/documenti-ateco/) · artefatto usato dal connettore: `StrutturaATECO-2025-IT-EN-DE.xlsx`
- NACE Rev. 2.1 (Eurostat): [pagina NACE](https://ec.europa.eu/eurostat/web/nace) · [EUR-Lex sintesi](https://eur-lex.europa.eu/EN/legal-content/summary/statistical-classification-of-economic-activities-nace-revision-2-1.html)
- ISCO-08 (ILO): [ISCO](https://www.ilo.org/public/english/bureau/stat/isco/isco08/)
- CP2021 (Istat): [Classificazione delle professioni](https://www.istat.it/en/classification/classification-of-occupations/) · [Focus CP2021 (PDF)](https://www.istat.it/wp-content/uploads/2024/01/FOCUS_PROFESSIONI_2021.pdf)
- ESCO (UE): [ESCO portal](https://esco.ec.europa.eu/en)

---
*Prodotto da Cowork in modalità read-only sulla SoT di heuresys-advanced. Nessuna scrittura sul progetto oltre la proposta in `docs/kb/COWORK_INBOX.md`. DDL = PROPOSED / DO-NOT-APPLY.*
